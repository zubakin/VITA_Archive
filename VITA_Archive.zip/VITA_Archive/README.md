# VITA_Archive

Открытый архив смыслов на базе VITA+.

## Что это?

Каждый `.txt` — это зафиксированный смысл (VITA_чанк), пригодный для DAO-оценки, хранения и трансформации в IDcoin.

## Структура

- `/manifest/` — содержит официальный манифест системы.
- `/examples/chanks/` — примеры чанков.
- `README.md` — описание проекта.

## Как добавить свой чанк?

1. Создайте файл в `/examples/chanks/ВАШЕ_ИМЯ_ДАТА.txt`.
2. Формат:
   ```
   Заголовок: ...
   Текст: ...
   Дата: ...
   VITA_ID: ...
   IDcoin: ...
   Связи: ...
   ```
3. Загрузите через Pull Request.

## Ссылки

- [Манифест на IPFS](https://gateway.pinata.cloud/ipfs/QmUuMRBvCwxtU9SUZTLo4TqLezPy6eMwNaM3LJJ5iZGU3q)
